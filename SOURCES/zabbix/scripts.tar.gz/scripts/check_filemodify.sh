#!/bin/bash

fFILENAME=$1

cDATE=`date "+%Y%m%d%H%M"`

if [ $# -lt 1 ];then
    echo "[FAIL] no argument"
    exit 1
fi
    
if [ ! -f $fFILENAME ];then
    echo "[FAIL] $fFILENAME not exist!"
    exit 2
fi

sDIRNAME=`/usr/bin/dirname ${fFILENAME}`
sBASENAME=`/bin/basename ${fFILENAME}`

if [ -f ${sDIRNAME}/.${sBASENAME}.last ];then
    #diff
#    /usr/bin/diff -uNr $fFILENAME ${sDIRNAME}/.${sBASENAME}.last >& /tmp/diff${sBASENAME}
    /usr/bin/diff -uNr ${sDIRNAME}/.${sBASENAME}.last $fFILENAME >& /tmp/diff${sBASENAME}
    if [ $? -ne 0 ];then
	cp -a $fFILENAME ${sDIRNAME}/.${sBASENAME}.last
	/bin/egrep '^(\+|\-)AllowGroups( |.)+lg_(security|tmp.+)' /tmp/diff${sBASENAME} >& /dev/null
	if [ $? -eq 0 ];then
	    echo "[OK] $fFILENAME was modified, but that is lg_tmp...."
	    exit 0
	else
	    echo "[FAIL] $fFILENAME was modified"
	    cat /tmp/diff${sBASENAME}
	    exit 10
	fi
    else
	echo "[OK] $fFILENAME is not modified"
	exit 0
    fi
else
    cp -a $fFILENAME ${sDIRNAME}/.${sBASENAME}.last
    echo "[OK] $fFILENAME backup to ${sDIRNAME}/.${sBASENAME}.last"
    exit 0
fi
