#!/bin/bash

umask 0027

fTMP=/tmp/zabbix_`basename $0`
#echo $fTMP

rm -f $fTMP >& /dev/null
touch $fTMP >& /dev/null
stat $fTMP >& /dev/null

RET_VAL=$?
echo $RET_VAL
exit $RET_VAL
