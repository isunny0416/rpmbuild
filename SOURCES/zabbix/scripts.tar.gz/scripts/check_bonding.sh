#!/bin/bash

# return value
# 0 : OK
# 1 : mode fail
# 2 : speed fail
# 4 : interface number is not 2
# 8 : some interface is down


#DATE=`date "+--%Y-%m-%d %H:%M:%S-- "`
RETVAL=0

SPEED=0
if [ $# -eq 0 ];then
    # default
#    SPEED="0"
    if [ -f /proc/net/bonding/bond0 ];then
	for C_SPEED in `grep  '^Speed' /proc/net/bonding/bond0  | awk '{print $2}'`
	do
	    [ $C_SPEED -gt $SPEED ] && SPEED=$C_SPEED
	done
    else
	SPEED="1000"
    fi
    
elif [ -z $1 ];then
    SPEED="1000"
else
    SPEED=$1
fi

if [ $# -lt 2 ] || [ -z $2 ];then
    # default
    BONDDEV=bond0
else
    BONDDEV=$2
fi

if [ $# -lt 3 ] || [ -z $3 ];then
    # default
    MODE='fault-tolerance'
else
    MODE=$3
fi

if [ $# -lt 4 ] || [ -z $4 ];then
    # default
    SLAVE_COUNT='2'
else
    SLAVE_COUNT=$4
fi

if [ -f /app/zabbix/etc/bond.conf ] && [ `grep -c ^${BONDDEV} /app/zabbix/etc/bond.conf` -ge 1 ];then
    SPEED2=`grep ^${BONDDEV} /app/zabbix/etc/bond.conf | tail -1 | awk -F':' '{print $2}'`
    MODE2=`grep ^${BONDDEV} /app/zabbix/etc/bond.conf | tail -1 | awk -F':' '{print $3}'`
    SLAVE_COUNT2=`grep ^${BONDDEV} /app/zabbix/etc/bond.conf | tail -1 | awk -F':' '{print $4}'`
fi

[ ! -f /app/zabbix/etc/bond.conf ] && echo '#bond0:1000:load balancing:2' > /app/zabbix/etc/bond.conf

SPEED2=${SPEED2:-notset}
MODE2=${MODE2:-notset}

echo $SLAVE_COUNT2 | egrep -e '[0-9]+$' >& /dev/null
[ $? -eq 0 ] && [ $SLAVE_COUNT2 -lt $SLAVE_COUNT ] && SLAVE_COUNT=$SLAVE_COUNT2

echo $BONDDEV | grep '^bond' > /dev/null
if [ $? -eq 0 ] && [ `/sbin/ifconfig |grep -c $BONDDEV` -gt 0 ] && [ -f /proc/net/bonding/${BONDDEV} ];then
    # if bond0.1.2.3.4
    grep "^MII Status: down" /proc/net/bonding/${BONDDEV} >& /dev/null
    if [ $? -ne 0 ];then
	# active bond interface
	egrep -e "^Bonding Mode: ${MODE}|^Bonding Mode: ${MODE2}" /proc/net/bonding/${BONDDEV} >& /dev/null
	[ $? -ne 0 ] && let "RETVAL= $RETVAL + 1"

#	echo "egrep -c -w -e \"^Speed: ${SPEED}|Speed: ${SPEED2}\" /proc/net/bonding/${BONDDEV}"
	if [ `egrep -c -w -e "^Speed: ${SPEED}|Speed: ${SPEED2}" /proc/net/bonding/${BONDDEV}` -lt $SLAVE_COUNT ];then
	    let "RETVAL= $RETVAL + 2"
	fi  

	if [ `grep -c "^Slave Interface:" /proc/net/bonding/${BONDDEV}` -lt $SLAVE_COUNT ];then
	    let "RETVAL= $RETVAL + 4"
	fi
    else
	RETVAL=8
    fi
#else
#    CUR_SPEED=`/sbin/ethtool $BONDDEV |grep 'Speed:'`
#    if [ $? -eq 0 ];then
#	CUR_SPEED=`echo $CUR_SPEED | awk '{print $2}'`
#	if [ "$CUR_SPEED" != "${SPEED}Mb/s" ];then
#	    let "RETVAL= $RETVAL + 2"
#	fi
#    fi
fi

echo $RETVAL
exit $RETVAL
