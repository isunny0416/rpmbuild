#!/bin/bash

PHYSICAL=`dmidecode -s system-manufacturer | egrep -ci "HP|IBM|Dell|Supermicro"`
XENSERVER=`uname -r | grep -ci "xen"`
NOTSUPPORT=`egrep -ci "5160|E3-1220|E5-2407|E5-2603|E5-2609|E5430|E5504|E5606|E5607" /proc/cpuinfo`

if [ $PHYSICAL -ne 0 ] && [ $XENSERVER -eq 0 ] && [ $NOTSUPPORT -eq 0 ]
then
    THREADS=`grep "siblings" /proc/cpuinfo | head -1 | awk '{ print $NF }'`
    CORES=`grep "cpu cores" /proc/cpuinfo | head -1 | awk '{ print $NF }'`
    if [ $THREADS -eq $CORES ]
    then
	echo 1
    else
	echo 0
    fi
else
    echo 0
fi

exit 0
