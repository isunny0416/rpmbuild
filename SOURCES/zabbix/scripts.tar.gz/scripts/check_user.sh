#!/bin/bash

SC_PATH="/app/zabbix/scripts"

if [ $# -lt 1 ];then
    echo "[FAIL] no scripts!"
    exit 100
fi

SCRIPTS=$1

if [ ! -f ${SC_PATH}/${SCRIPTS} ];then
    echo "[FAIL] file not found! - ${SC_PATH}/${SCRIPTS}"
    exit 255
fi

[ -x ${SC_PATH}/${SCRIPTS} ] || chmod u+x ${SC_PATH}/${SCRIPTS}

${SC_PATH}/${SCRIPTS} "$2" "$3" "$4" "$5" "$6" "$7" "$8" "$9" "${10}"
exit $?
