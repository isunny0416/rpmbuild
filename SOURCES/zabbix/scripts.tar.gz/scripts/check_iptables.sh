#!/bin/bash

### Return Value
# null : OK
# anything : FAIL

mFREE=`df -P /tmp | grep "/$" | awk '{print $4}'`
[ -z $mFREE ] && echo "[ok] /tmp free low" && exit 0
[ $mFREE -lt 16384 ] && echo "[ok] /tmp free low" && exit 0

source /etc/profile >& /dev/null

fEMPTY="empty_iptables.txt"
fTMP="/tmp/iptables_ret"
fRET_DIFF="/tmp/iptables_retdiff"

#[ -z $REPO ] && REPO=10.10.100.20
#[ ! -f /root/$fEMPTY ] && rsync -av ${REPO}::D/STD/OS/${fEMPTY} /root/ >& /dev/null
if [ ! -f /root/$fEMPTY ]; then
    mkdir -p /root/
    echo "Chain INPUT (policy ACCEPT)
target     prot opt source               destination         

Chain FORWARD (policy ACCEPT)
target     prot opt source               destination         

Chain OUTPUT (policy ACCEPT)
target     prot opt source               destination         " > /root/$fEMPTY
fi

[ -f $fTMP ] && rm -f $fTMP
[ -f $fRET_DIFF ] && rm -f $fRET_DIFF

/sbin/iptables -nL > $fTMP

if [ -f /root/$fEMPTY ] && [ -f $fTMP ];then
#    /usr/bin/diff -uNr /root/$fEMPTY $fTMP >& /dev/null
    /usr/bin/diff -uNr /root/$fEMPTY $fTMP >& $fRET_DIFF
    if [ $? -ne 0 ];then 
	cat $fRET_DIFF
    else
	echo "[ok]"
    fi
else
    # file not exist
    echo "file not exist - /root/${fEMPTY} or $fTMP"
fi

[ -f $fTMP ] && rm -f $fTMP
[ -f $fRET_DIFF ] && rm -f $fRET_DIFF

exit 0
