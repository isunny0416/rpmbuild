#!/bin/bash

ls -l $1
