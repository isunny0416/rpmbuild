#!/bin/bash

source /etc/profile
export LANG=C
#/sbin/ldconfig
cDATE=`date "+%Y%m%d%H%M"`
unset bCOMMON

## /root/job/common.conf define variables
# sIDC REPO TIMESERVER sHOSTNAME LDAPSRV SYSLOG_IP MGMTBK_IP SMTPSERVER 
# HP_HWMON DNS_SEARCH DNS_SERVER ZABBIX_SERVER APPROOT DOCROOT SRC 
# CPU_COUNT THREAD sARCH bRHEL OSVER OSVER_DETAIL sOSTYPE CRONTAB_DIR CROND 
# YUMCMD bRHEL noRHEL sKERNEL IPADDR NET3 NETTYPE NETaddr HWVENDOR sIDC
# sHWMODEL sSERIAL

sIDC='X'

############################################################################
#for external IDC
############################################################################
[ -z "$REPO" ] && REPO='NA'
[ -z "$TIMESERVER" ] && TIMESERVER='NA'
[ -z "$sHOSTNAME" ] && sHOSTNAME=`hostname -s`
[ -z "$LDAPSRV" ] && LDAPSRV='NA'
[ -z "$SYSLOG_IP" ] && SYSLOG_IP='NA'
[ -z "$MGMTBK_IP" ] && MGMTBK_IP='NA'
[ -z "$SMTPSERVER" ] && SMTPSERVER='NA'
[ -z "$HP_HWMON" ] && HP_HWMON='NA'
[ -z "$DELL_HWMON" ] && DELL_HWMON='NA'
[ -z "$DNS_SEARCH" ] && DNS_SEARCH=''
[ -z "$DNS_SERVER" ] && DNS_SERVER=''
[ -z "$ZABBIX_SERVER" ] && ZABBIX_SERVER='NA'
[ -z "$SGATE" ] && SGATE=10.40.30.214

############################################################################
# color def
############################################################################
red="\033[31m"
green="\033[32m"
yellow="\033[33m"
blue="\033[34m"
magenta="\033[35m"
cyan="\033[36m"
white="\033[37m"
reset="\033[0m"
############################################################################

APPROOT=/app
DOCROOT=${APPROOT}/docroot
SRC=$APPROOT/src
[ ! -d ${SRC}/bak ] && mkdir -p ${SRC}/bak
[ ! -d ${APPROOT}/log ] && mkdir -p ${APPROOT}/log  && chmod +rx ${APPROOT}/log

chmod a+xr ${APPROOT} ${APPROOT}/log
chmod 777 $SRC
#chmod a+r /etc/hosts

CPU_COUNT=`cat /proc/cpuinfo | grep processor | wc -l`
if [ $CPU_COUNT -gt 8 ]; then
    let "THREAD= $CPU_COUNT / 2"
else
    THREAD=$CPU_COUNT
fi

sARCH=`uname -m`
bRHEL="n"
OSVER='unknown'
OSVER_DETAIL='unknown'
sOSTYPE='RH'
sOSVENDOR="CentOS"

if [ -f /usr/bin/lsb_release ] && [ `lsb_release -is` = 'Ubuntu' ];then
    sOSTYPE='UT'
    OSVER="`lsb_release -rs`"
    OSVER_DETAIL="Ubuntu${OSVER}-${sARCH}"
    CRONTAB_DIR='/var/spool/cron/crontabs'
    CROND='cron'
    YUMCMD='apt-get'
    SSHD='ssh'
    sOSVENDOR="UBUNTU"
else
    sOSTYPE='RH'
    CRONTAB_DIR='/var/spool/cron'
    CROND='crond'
    YUMCMD='yum'
    SSHD='sshd'

    [ ! -f /etc/system-release ] && ln -s /etc/redhat-release /etc/system-release
    sKERNEL=`uname -r`
    #    if [ `uname -r | grep -i -c '.el'` -eq 0 ] && [ `uname -r | grep -i -c 'xen'` -ge 1 ];then
    if [ -f /etc/xensource-inventory ];then
	OSVER=XEN
	#       OSVER_DETAIL="XEN`uname -r | awk -F'.' '{print $11}'|sed 's/xen//g'`-$sARCH"
	OSVER_DETAIL="XenServer`grep "^PRODUCT_VERSION_TEXT=" /etc/xensource-inventory | awk -F= '{print $2}' | awk -F"'" '{print $2}'`-$sARCH"
	sOSVENDOR="XEN"
    else
	if [ `grep -i -c 'centos' /etc/system-release` -ge 1 ];then
	    OSVER_DETAIL="CentOS`awk '{print $3}' /etc/system-release`-${sARCH}"
	    sOSVENDOR="CentOS"
	elif [ `grep -i -c 'oracle' /etc/system-release` -ge 1 ];then
	    OSVER_DETAIL="Oracle`awk '{print $5}' /etc/system-release`-${sARCH}"
	    sOSVENDOR="OracleLinux"
	elif [ `grep -i -c 'red hat' /etc/system-release` -ge 1 ];then
	    if [ -f /etc/centos-release ];then
		OSVER_DETAIL="CentOS`awk '{print $7}' /etc/system-release`-${sARCH}"
		sOSVENDOR="CentOS"
	    else
		OSVER_DETAIL="RedHat`awk '{print $7}' /etc/system-release`-${sARCH}"
		sOSVENDOR="RHEL"
	    fi
	fi

	echo $sKERNEL | grep -i el6 >> /dev/null
	[ $? -eq 0 ] && OSVER=EL6

	echo $sKERNEL | grep -i el5 >> /dev/null
	[ $? -eq 0 ] && OSVER=EL5

	if [ "$OSVER" = "unknown" ];then
	    echo "$OSVER_DETAIL" | grep '4.' >& /dev/null
	    [ $? -eq 0 ] && OSVER=EL4
	fi
    fi
fi

noRHEL=$sOSVENDOR

IPADDR=`/sbin/ip route get $SGATE | head -1 | awk '{print $NF}'`

egrep '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$' <<< $IPADDR >& /dev/null
#if [ -z $IPADDR ];then
if [ $? -ne 0 ];then
    IPADDR=`/sbin/ip addr | grep -w inet | egrep -v '127\.0\.0\.1|/32 scope|scope global .*:[0-9]$|global secondary' | awk '{ print $2 }' | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep -v '^211\.110\.|^1\.234\.|^175\.|^192\.168\.|^10.22[1-2]\.|^10\.10\.9[0-6]\.|^50\.0\.|^60\.0\.|^75\.0\.|^76\.0\.|^70\.0\.' | head -n 1`
fi

NET3=`echo $IPADDR | awk -F. '{print $3}'`

# dev zone
NETaddr=`echo $IPADDR | awk -F. '{print $1"."$2"."$3}'`
case $NETaddr in
    172.19.107 | 172.19.11[2-5] | 172.21.3[2-9] | 172.21.4[0-6] | 172.22.24[0-7] | \
    172.21.6[0-3] | 172.21.19[2-6] | 172.21.236 )
    NETTYPE="DEV"
    ;;
    * )
    NETTYPE="PROD"
    ;;
esac

HWSTR=`grep "Vendor:" /proc/scsi/scsi | awk '{print $2}'`

HWVENDOR="unknown"
if [ `echo $HWSTR | grep -i -c ibm` -ge 1 ]; then
    HWVENDOR="ibm"
elif [ `echo $HWSTR | grep -i -c hp` -ge 1 ]; then
    HWVENDOR="hp"
elif [ `echo $HWSTR | grep -i -c dell` -ge 1 ]; then
    HWVENDOR="dell"
elif [ `echo $HWSTR | grep -i -c necvmwar` -ge 1 ]; then
    HWVENDOR="vm_vmware"
elif [ `echo $HWSTR | grep -i -c VMware` -ge 1 ]; then
    HWVENDOR="vm_vmware"
elif [ `fdisk -l 2>1 | grep -c '^Disk /dev/cciss'` -ge 1 ]; then
    HWVENDOR="hp"
elif [ `fdisk -l 2>1 |grep -c xvd` -ge 1 ]; then
    HWVENDOR="vm_xen"
elif [ `lsmod |grep -c virtio_blk` -ge 1 ]; then
    HWVENDOR="vm_kvm"
fi

if [ -f /usr/sbin/dmidecode ];then
    if [ $HWVENDOR != "vm_xen" ];then
	sHWMODEL=`/usr/sbin/dmidecode -s system-product-name | tail -n1 |awk -F- '{print $1}' | awk -F: '{print $1}' |sed -e 's/^*//g' | sed -e 's/IBM//g' | tr -d [:blank:]`
	sSERIAL=`/usr/sbin/dmidecode -s system-serial-number | tail -n1 |sed -e 's/^*//g' | tr -d [:blank:]`
    else
	sHWMODEL="vm_xen"
	sSERIAL="vm_xen"
    fi
else
    sHWMODEL="need_dmi"
    sSERIAL="need_dmi"
fi


bCOMMON=1
