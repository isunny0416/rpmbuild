#!/bin/bash
## last modify hc.song@sk.com  2014/02/05

## 주의!!!!! 본 스크립트는 모든 서버에 주기적으로 실행되기 때문에
## 수정시 특별한 주의를 기우릴것!

source /etc/profile >& /dev/null

[ -z $REPO ] && REPO="10.10.100.20"
[ -z $APPROOT ] && APPROOT="/app"
[ -z "$SGATE" ] && SGATE=10.40.30.214

grep '^NETaddr' /usr/bin/whatidc >& /dev/null
if [ $? -ne 0 ];then
    /usr/bin/curl --connect-timeout 1 http://${REPO}/whatidc -o /usr/bin/whatidc >& /dev/null
    grep '^NETaddr' /usr/bin/whatidc >& /dev/null
    if [ $? -ne 0 ];then
	echo > /usr/bin/whatidc
    fi
    chmod a+x /usr/bin/whatidc >& /dev/null
fi

IPADDR=`/sbin/ip route get $SGATE | head -1 | awk '{print $NF}'`

egrep '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$' <<< $IPADDR >& /dev/null
#if [ -z $IPADDR ];then
if [ $? -ne 0 ];then
    IPADDR=`/sbin/ip addr | grep -w inet | egrep -v '127\.0\.0\.1|/32 scope|scope global .*:[0-9]$|global secondary' | awk '{print $2 }' | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep -v '^11\.0\.4\.|^11\.0\.0\.|^11\.0\.3\.|^211\.110\.|^1\.234\.|^175\.|^50\.0\.|^60\.0\.|^75\.0\.|^76\.0\.|^70\.0\.|^11\.0\.2|^192\.168\.0\.|^192\.168\.100\.' | head -n 1`
fi

case "X`/usr/bin/whatidc $IPADDR`" in
    # commerce center
    XCM|XCD)
    sIDC=C
    REPO=10.10.64.20
    ;;

    # sungsu commerce center
    XSC)
    sIDC=S
    REPO=10.251.14.20
    ;;

    # sungsu center
    XSS)
    sIDC=T
    REPO=10.251.8.24
    ;;

    # ilan sungsu dev
    XSD|XSV)
    sIDC=T
    REPO=10.251.8.24
    ;;

    # ilan center
    XIS|XID)
    sIDC=I
    REPO=10.10.100.20
    ;;

    # ilan external center
    XIX)
    sIDC=X
    REPO=10.10.100.20
    ;;

    #seocho
    XSM)
    sIDC=M
    REPO=172.22.3.9
    ;;

    *)
    echo -e "This server is not in SKPlanet-IDC. IP-${IPADDR}\n" 
#    rsync --contimeout=1 -avL $REPO::D/STD/zabbix/scripts_ext/ ${APPROOT}/zabbix/scripts/ >& /dev/null
    /usr/bin/curl --connect-timeout 1 http://${REPO}/garbage-disposal_ext.sh -o  ${APPROOT}/zabbix/scripts/garbage-disposal.sh >& /dev/null
    chown -R zabbix.zabbix ${APPROOT}/zabbix/scripts/ >& /dev/null
    chmod +x ${APPROOT}/zabbix/scripts/*
    exit 10
    ;;
esac

mkdir -p /root/job/
#rsync -avL --contimeout=1 ${REPO}::D/STD/OS/common.conf /root/job/common.conf.new >& /dev/null
/usr/bin/curl --connect-timeout 1 http://${REPO}/common.conf -o /root/job/common.conf.new >& /dev/null
source /root/job/common.conf.new >& /dev/null

if [ -z $bCOMMON ] || [ -z $sIDC ];then
    if [ `rpm -q zabbix-agentd | grep -c skpext` -ge 1 ];then
	sIDC=X
    else
#	rsync --contimeout=1 -avL $REPO::D/STD/zabbix/scripts_ext/ ${APPROOT}/zabbix/scripts/ > /dev/null
	/usr/bin/curl --connect-timeout 1 http://${REPO}/garbage-disposal_ext.sh -o  ${APPROOT}/zabbix/scripts/garbage-disposal.sh > /dev/null
	chown -R zabbix.zabbix ${APPROOT}/zabbix/scripts/
	chmod +x ${APPROOT}/zabbix/scripts/*
	echo "[ERR] /root/job/common.conf not include!" && exit 100
    fi
fi
/bin/mv -f  /root/job/common.conf.new /root/job/common.conf

bFORCE=0
[ ! -z $1 ] && [ "0$1" = "0-f" ] && bFORCE=1

bALL=0
[ ! -z $2 ] && [ "0$2" = "0all" ] && bALL=1

COMMON_RPM() {
    [ ! -f /bin/awk ] && ln -s /usr/bin/awk /bin/awk
    [ ! -f /bin/basename ] && ln -s /usr/bin/basename /bin/basename
    [ ! -f /bin/find ] && ln -s /usr/bin/find /bin/find
}

############# MAIN #################

PROFILE_REPO() {
    grep "^export REPO=${REPO}" /etc/profile >& /dev/null
    if [ $? -eq 1 ]; then
	/usr/bin/perl -p -i -e "s/^export REPO=/#export REPO=/g" /etc/profile
	echo "export REPO=${REPO}" >> /etc/profile
    fi
}

CHECK_BONDING() {
    sIF1=`/sbin/ifconfig | grep 'Link encap:Ethernet' | head -n 1 | awk '{print $1}'`

    if [ "0${sIF1}" = "0bond0" ];then
	#       ${APPROOT}/zabbix/scripts/check_bonding.sh 1000 bond0 fault-tolerance >& /dev/null
	${APPROOT}/zabbix/scripts/check_bonding.sh >& /dev/null
	nRET=$?
	if [ $nRET -ne 0 ];then
	    echo "bond0 status fail!"
	fi
    fi
}

SYNC_SCRIPTS() {
    #### zabbix sync
    rsync -avL $REPO::D/STD/zabbix/agent/userparams.conf ${APPROOT}/zabbix/etc/userparams.conf > /dev/null
    [ ! -f ${APPROOT}/zabbix/etc/userparams2.conf ] && touch ${APPROOT}/zabbix/etc/userparams2.conf

    if [ "0${sIDC}" = "0I" ] || [ "0${sIDC}" = "0C" ] || [ "0${sIDC}" = "0S" ];then
	rsync -avL $REPO::D/STD/zabbix/scripts/ ${APPROOT}/zabbix/scripts/ > /dev/null
    else
	rsync -avL $REPO::D/STD/zabbix/scripts_ext/ ${APPROOT}/zabbix/scripts/ > /dev/null
    fi

    rsync -avuL $REPO::D/STD/OS/svc_useradd.sh /root/job/ > /dev/null
    rm -f ${APPROOT}/zabbix/scripts/.*.swp.* ${APPROOT}/zabbix/scripts/.*.last
    rsync -avL $REPO::D/STD/zabbix/addon/ ${APPROOT}/zabbix/bin/addon/ > /dev/null
    rsync -avL $REPO::D/STD/zabbix/nagios-plugins/ ${APPROOT}/zabbix/bin/nagios-plugins/ > /dev/null

    chown -R zabbix.zabbix ${APPROOT}/zabbix/etc ${APPROOT}/zabbix/scripts/ ${APPROOT}/zabbix/bin/addon/ ${APPROOT}/zabbix/bin/nagios-plugins/

    rsync -avL $REPO::D/STD/OS/whatidc /usr/bin/ > /dev/null

    chown root.zabbix ${APPROOT}/zabbix/scripts/zabbix_agentup.sh
    chmod 740 ${APPROOT}/zabbix/scripts/zabbix_agentup.sh
}

AGENT_CONF() {
    # zabbix_agentd.conf userparams.conf
#    rsync -av $REPO::D/STD/zabbix/agent/zabbix_agentd.conf $REPO::D/STD/zabbix/agent/userparams.conf ${APPROOT}/zabbix/etc/
    rsync -avL $REPO::D/STD/zabbix/agent/zabbix_agentd.conf ${APPROOT}/zabbix/etc/
    rsync -avL $REPO::D/STD/zabbix/agent/userparams.conf ${APPROOT}/zabbix/etc/

    echo $NETaddr | egrep '10.251.1[2-5]' >& /dev/null
    if [ $? -eq 0 ];then
	/usr/bin/perl -p -i -e "s/ServerActive=.+$/ServerActive=10.10.68.39/g" ${APPROOT}/zabbix/etc/zabbix_agentd.conf
    else
	/usr/bin/perl -p -i -e "s/^ServerActive=.+$/ServerActive=${ZABBIX_SERVER}/g" ${APPROOT}/zabbix/etc/zabbix_agentd.conf
    fi

    if [ "0${sIDC}" = "0M" ];then
	/usr/bin/perl -p -i -e "s/^ServerActive=.+$/ServerActive=${ZABBIX_SERVER}/g" ${APPROOT}/zabbix/etc/zabbix_agentd.conf
	/usr/bin/perl -p -i -e "s/^Server=/Server=${ZABBIX_SERVER},/g" ${APPROOT}/zabbix/etc/zabbix_agentd.conf
    fi

    [ ! -f ${APPROOT}/zabbix/etc/userparams2.conf ] && touch ${APPROOT}/zabbix/etc/userparams2.conf

    if [ "0${sIDC}" = "0I" ] || [ "0${sIDC}" = "0C" ] || [ "0${sIDC}" = "0S" ];then
	rsync -avL $REPO::D/STD/zabbix/scripts/ ${APPROOT}/zabbix/scripts/ > /dev/null
    else
	rsync -avL $REPO::D/STD/zabbix/scripts_ext/ ${APPROOT}/zabbix/scripts/ > /dev/null
    fi

    echo $sHOSTNAME | egrep -e 'zabbix[0-9]+$' >& /dev/null
    if [ $? -eq 0 ];then
	# if zabbix server
	grep '^Server=' ${APPROOT}/zabbix/etc/zabbix_agentd.conf | grep '10.10.68.198,10.10.68.199' >& /dev/null
	if [ $? -ne 0 ];then
#	    /usr/bin/perl -p -i -e 's/,127\.0\.0\.1/,10.10.68.198,10.10.68.199,127.0.0.1/g' ${APPROOT}/zabbix/etc/zabbix_agentd.conf
	    /usr/bin/perl -p -i -e 's/^(Server=.+)$/${1},10.10.68.198,10.10.68.199/g' ${APPROOT}/zabbix/etc/zabbix_agentd.conf
	fi
    fi

    /bin/chmod 0755 ${APPROOT}/zabbix
    /bin/chmod 0750 ${APPROOT}/zabbix/etc ${APPROOT}/zabbix/log ${APPROOT}/zabbix/run ${APPROOT}/zabbix/sbin/ ${APPROOT}/zabbix/scripts
    /bin/chmod 0755 -R ${APPROOT}/zabbix/bin

    /bin/chown -R zabbix.zabbix ${APPROOT}/zabbix
    chown root.zabbix ${APPROOT}/zabbix/scripts/zabbix_agentup.sh
    chmod 740 ${APPROOT}/zabbix/scripts/zabbix_agentup.sh
    
    [ -x ${APPROOT}/zabbix/scripts/restart_zagent.sh ] && ${APPROOT}/zabbix/scripts/restart_zagent.sh
}

SET_cmdb() {
    rsync -aL ${REPO}::D/STD/CMDB/script/cmdbcron /etc/cron.d/
    grep "@@PATH@@" /etc/cron.d/cmdbcron >& /dev/null
    [ $? -eq 0 ] && /usr/bin/perl -p -i -e "s#\@\@PATH\@\@#${APPROOT}/zabbix/scripts#g" /etc/cron.d/cmdbcron
}


## main
## 주의!!!!! 본 스크립트는 모든 서버에 주기적으로 실행되기 때문에
## 수정시 특별한 주의를 기우릴것!

chmod +r /etc/hosts

RFS_FREE=`/bin/df -P -k / |grep '/$' | awk '{print $4}'`
if [ -z $RFS_FREE ] || [ $RFS_FREE -le 50000 ] ;then
    # free가 50M가 안되면 실행하지 않음
    echo "GARBAGE-DISPOSAL LOW-FREE - $cDATE $sHOSTNAME $IPADDR $RFS_FREE"
    exit 100
fi

PROFILE_REPO

if [ -z $RFS_FREE ] || [ $RFS_FREE -le 200000 ] ;then
    # free가 400M가 안되면 실행하지 않음
    echo "GARBAGE-DISPOSAL LOW-FREE - $cDATE $sHOSTNAME $IPADDR $RFS_FREE"
    exit 100
fi

# 날짜와 IP가 3으로 나눈 나머지가 같을때 만 실행
# 즉 여기서부터는 3일에 한번 실행됨
if [ $bFORCE -eq 0 ];then
    dMOD=3
    let "nDAY= `date +%e` %  ${dMOD}"
    dLASTIP=`echo $IPADDR | awk -F'.' '{print $4}'`
    let "dLASTIP= $dLASTIP % ${dMOD}"

    if [ $dLASTIP -ne $nDAY ];then
	rsync -avL $REPO::D/STD/zabbix/scripts_ext/garbage-disposal.sh ${APPROOT}/zabbix/scripts/ > /dev/null
	echo "GARBAGE-DISPOSAL PASS - $cDATE $sHOSTNAME $IPADDR $nDAY $dLASTIP"
	exit 0
    fi
fi

SYNC_SCRIPTS

#  추가 항목, 모두적용 후 주석처리해야함
COMMON_RPM
SET_cmdb

if [ $bALL -eq 1 ];then
    AGENT_CONF
else
    CHECK_BONDING
fi

wait
echo "GARBAGE-DISPOSAL OK - $cDATE $sHOSTNAME $IPADDR"

exit 0
