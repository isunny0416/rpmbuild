#!/bin/bash


# 1, 주요 내용 - ATP로 체크하던 방식을 zabbix userparameter 형태로 변경 - checkdmesg.sh 파일을 만들어 주시면 됩니다.
#  - checkdmesg.sh 뒤에 인자가 오며 인자가 없으면 “10503000”을 출력합니다.
if [ "$1" == "" ] ; then
    echo "10503000"
    exit
fi
#  - 대소문자를 구분합니다.
# 
# 2. zabbix item parameter
# UserParameter=user.dmesg[*],/usr/local/zabbix/bin/checkdmesg.sh "$1"
# 
# 3. 생성 스크립트 디렉터리 및 파일명
# 디렉터리 : /usr/local/zabbix/bin
# 작업 파일명 : checkdmesg.sh
# 
# 4. 체크형태
#   형태 : 스크립트명 “인자”
# [root@xp3mon1 pkg_zabbix]# sh checkdmesg.sh "I/O Error"
# 
# 5. 반환 값
# 반환 형태 : 정수
# 0 -> 정상
# 1이상 -> 발생 카운터 수
# …..
# 예를 들어 “I/O Error”가 100번 발생하면 100을 반환해야 합니다.
# 즉, 반환 값은 발생 총 라인 수를 뜻합니다.
result=`dmesg | grep -v 'dev fd0' | grep -c -i "$1"`
echo $result

if [ $result -gt 0 ] && [ ! -z $2 ];then
    dmesg -c > /dev/null
fi
# 
# 6. 인자(argument)로 올 수 있는 사례
# "EXT2-fs error"
# "EXT3-fs error"
# "SCSI disk error"
# "SCSI Error"
# "I/O error"
# "Out of Memory"
# "SCSI hang ?"
# "FAIL state entered"
# "ip_conntrack: table full, dropping packet"
# "allocation failed: out of vmalloc space"
# "martian sourc"
# "Unable to handle kernel"
# "mptscsi: ioc0: attempting task abort"
# "possible deadlock in kmem_alloc"
# "Neighbour table overflow"
# "Non-Fatal Error DRAM Controler"
# "rejecting I/O to dead device"
# "sense key Hardware Error"
# 이상.

