#!/bin/bash

## hc.song@sk.com
## ver 1.0.0
##############################################################################
## Arg1 : 다운받을 파일명
## Arg2 : UPDATE or update 값일 경우 스크립트가 있더라도 download 후 실행(생략가능)
##############################################################################
## Retry 회수 및 Retry 제한 회수 설정
RETRY=0
LIMITRETRY=3
## local directory path
LOCALDIR="/app/zabbix/scripts"
SUCCESS=0
FAIL="$0 run fail! - $0 $@"
DATE=`date +%Y%m%d%H%M%S`

source /etc/profile >& /dev/null
if [ -z $REPO ];then
    # check sungsu repo
    REPO=10.251.8.24
    echo "REPO is not set!"
    exit -1
fi

IS_SKP=0
case "$REPO" in
    10.10.100.20|10.10.64.20|10.251.14.20 )
    IS_SKP=1
    ;;
esac

##############################################################################

## Process check
PCHECK=`ps axf | grep "${LOCALDIR}/scriptrun.sh " | grep -v grep | wc -l`
if ! [ $PCHECK -lt 6 ];then
	echo $FAIL
	exit 0
fi

## script download
SYNC() {
#	echo "SYNC"
	## download
	while [ $RETRY -lt $LIMITRETRY ] ; do
		let RETRY=$RETRY+1

		rsync -aL --contimeout=2 $REPO::D/scripts/$NAME $LOCALDIR 2> /dev/null
		RRET=$?
		if [ $RRET -eq 0 ]; then
		    break
		elif [ $RRET -eq 23 ];then
		    echo "ERROR! file not fount - $REPO::D/scripts/$NAME"
		    echo $FAIL
		    exit -2
		fi

		## 일정시간 대기후 시도
		#echo "rsync retry - $RRET"
		let SLEEPSEC=$RANDOM/10000
		sleep $SLEEPSEC
	done
	## file download check
	if ! [ -f "$LOCALDIR/$NAME" ];then
		echo $FAIL
		exit -1
	fi
}

## script 실행
RUN() {
    if [ -f $LOCALDIR/$NAME ];then
	#	$LOCALDIR/$NAME 2> /dev/null
	chmod 750 $LOCALDIR/$NAME

	if [ $bBGRD -eq 1 ];then
	    rsync -aL --contimeout=2 $REPO::D/STD/zabbix/scripts/scriptrun_backgrd.sh ${LOCALDIR}/ 2> /dev/null
	    if [ -f ${LOCALDIR}/scriptrun_backgrd.sh ];then
		rm -f /tmp/${NAME}.log_*
		${LOCALDIR}/scriptrun_backgrd.sh ${LOCALDIR}/${NAME} ${DATE} 1> /tmp/${NAME}.log 2>&1 &
		echo "### Backup Ground Execute $NAME ${DATE}"
		echo "# ${LOCALDIR}/scriptrun_backgrd.sh ${LOCALDIR}/${NAME} ${DATE} 1> /tmp/${NAME}.log"
	    else
		${LOCALDIR}/${NAME} 2>&1
	    fi
	else
	    ${LOCALDIR}/${NAME} 2>&1
	fi
    else
	echo "ERROR) file not fount - $LOCALDIR/$NAME"
    fi
}

LOG() {
    HOSTIP=`ip r g 10.40.30.214 | head -n1 | awk '{print $NF}'`
    /usr/bin/logger -p local3.debug -t $LDAPID -- PID=$$ USER=$USER PWD=$PWD ConnIP=$REPO HOSTIP=$HOSTIP CMD="[ZRCMD] $NAME $bBGRD $DATE"
}
 
## 인수체크(최소 2개 이상)
# $1 script
# $2 update or ldapid
# $3 ldapid or -b(background)
# $4 -b(background)

[ ! -d $LOCALDIR ] && mkdir -p $LOCALDIR

## download script filename
NAME=$1

[ -z $NAME ] && echo "Script is NULL!" && exit -3

# 구버전에서 2번째 인자에 update가 들어오는 경우 무시
[ `echo $2 | grep -ci 'update'` -ge 1 ] && shift

#UPDATE=$2
#if [ -f "$LOCALDIR/$NAME" ];then
#	echo "${UPDATE}" | grep -i "update" >& /dev/null
#	if [ $? -eq 0 ];then
#		SYNC
#	fi
#else
#	SYNC
#fi
SYNC

LDAPID=$2
echo "$LDAPID" | egrep "^(pp[0-9]{5}|9[0-9]{2,3}|1[0-9]{6}|9[0-9]{6}|5[0-9]{6}|pg[0-9]{5})$|^cron_" >& /dev/null
if [ $? -eq 0 ];then
    shift
else
    LDAPID="pp91111"
fi

# 마지막 인자에 -b[yyyymmddhhmmss]가 들어올경우 background로 실행
bBGRD=0
BGEXEC=$2
if [ "0${BGEXEC:0:2}" = "0-b" ];then
    bBGRD=1
    [ "0${BGEXEC:2:2}" = "020" ] && DATE=${BGEXEC:2:14} 
    echo "$bBGRD ${BGEXEC:2:2} $DATE ${NAME}"
fi

if [ $IS_SKP -eq 1 ]; then
    LOG
    sHOSTNAME=`hostname -s`
    sIP=`/sbin/ip addr | grep -w inet | egrep -v '127.0.0.1|/32' | awk '{ print $2 }' | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep -v '^211.|^1.234|^175.' | head -n 1`

    ln -s ${LOCALDIR}/${NAME} /tmp/${NAME}_${DATE}
    rsync -aL --contimeout=2 /tmp/${NAME}_${DATE} ${REPO}::CMDLOG/${sHOSTNAME}_${sIP}/ >& /dev/null
    rm -f /tmp/${NAME}_20*
fi

# script 실행
RUN

exit
