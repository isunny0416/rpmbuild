#!/bin/bash

source /etc/profile
[ -z $REPO ] && REPO=10.10.100.20

rpm -q zabbix-agentd >& /dev/null
if [ $? -eq 0 ] && [ `rpm -q zabbix-agentd | grep -c '\.skp'` -eq 0 ];then
    echo "[ERR] rpm is not skplanet version" && exit 101
fi

mkdir -p /root/job/
rsync -avL ${REPO}::D/STD/OS/common.conf /root/job/common.conf.new > /dev/null
source /root/job/common.conf.new

[ -z $bCOMMON ] && echo "[ERR] /root/job/common.conf not include" && exit 100
/bin/mv -f  /root/job/common.conf.new /root/job/common.conf

## /root/job/common.conf define variables
# sIDC REPO TIMESERVER sHOSTNAME LDAPSRV SYSLOG_IP MGMTBK_IP SMTPSERVER 
# HP_HWMON DNS_SEARCH DNS_SERVER ZABBIX_SERVER APPROOT DOCROOT SRC 
# CPU_COUNT THREAD sARCH bRHEL OSVER OSVER_DETAIL sOSTYPE CRONTAB_DIR CROND 
# YUMCMD bRHEL noRHEL sKERNEL IPADDR NET3 NETTYPE NETTYPE HWVENDOR sIDC

export LANG=C

if [ "0${sIDC}" != "0I" ] && [ "0${sIDC}" != "0X" ] && [ "0${sIDC}" != "0C" ] && [ "0${sIDC}" != "0S" ] && [ "0${sIDC}" != "0M" ];then
    echo "Not support IDC - $sIDC"
    exit 100
fi

echo $IPADDR | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' >& /dev/null
if [ $? -ne 0 ];then
    echo "Unknown IPADDR(${IPADDR})."
    exit 99
fi

sDATE=`date "+%Y%m%d%H%M"`
RETMSG=
bFORCE=0
[ ! -z $1 ] && [ "0$1" = "0-f" ] && bFORCE=1

if [ $sOSTYPE = 'RH' ];then
    rpm -q zabbix-agentd >& /dev/null
    [ $? -ne 0 ] && bFORCE=1
fi

if [ `/bin/netstat -nltp | grep -c '0.0.0.0:10050'` -eq 0 ];then 
    bFORCE=1
fi

fLOG=${APPROOT}/zabbix/log/agent_update.log
fTMP="/tmp/${sHOSTNAME}_${IPADDR}_$sDATE"
fLASTUPDATE="${APPROOT}/zabbix/etc/last_update"

if [ -f $fLOG ] && [ `/usr/bin/stat -c %s $fLOG` -gt 10240000 ];then
    # 10MB
    /bin/mv -f $fLOG ${fLOG}.$sDATE
fi

if [ $bFORCE -eq 0 ];then
    sUPDATE_TIME=`/usr/bin/curl --connect-timeout 2 ${REPO}/zabbixup/updatetime 2> /dev/null`
    if [ $? -ne 0 ];then
	RETMSG="$sDATE $sHOSTNAME $IPADDR [ERR] \"curl command exec fail!\" \"/usr/bin/curl --connect-timeout 2 ${REPO}/zabbixup/updatetime\""
	echo $RETMSG >> $fLOG
	echo $RETMSG > $fTMP
	echo $RETMSG
	rsync -av $fTMP ${REPO}::TMP/zabbixup_${sUPDATE_TIME}_fail/
	rm -f $fTMP
	exit 1
    fi

    if [ ${sUPDATE_TIME:0:3} != 201 ];then
	RETMSG="$sDATE $sHOSTNAME $IPADDR [ERR] \"curl result is not datetype!\" \"${sUPDATE_TIME}\""
	echo $RETMSG >> $fLOG
	echo $RETMSG > $fTMP
	echo $RETMSG 
	rsync -av $fTMP ${REPO}::TMP/zabbixup_${sUPDATE_TIME}_fail/
	rm -f $fTMP
	exit 1
    fi

    dMOD=`/usr/bin/curl --connect-timeout 2 ${REPO}/zabbixup/mod 2> /dev/null`
    if [ $? -ne 0 ];then
	RETMSG="$sDATE $sHOSTNAME $IPADDR [ERR] \"curl command exec fail!\" \"/usr/bin/curl --connect-timeout 2 ${REPO}/zabbixup/mod\""
	echo $RETMSG >> $fLOG
	echo $RETMSG > $fTMP
	echo $RETMSG
	rsync -av $fTMP ${REPO}::TMP/zabbixup_${sUPDATE_TIME}_fail/
	rm -f $fTMP
	exit 1
    fi

    ISNUMBER=${dMOD//[0-9]/}
    if [ ! -z "$ISNUMBER" ] ; then
	RETMSG="$sDATE $sHOSTNAME $IPADDR [ERR] \"mod is not number!\" \"${dMOD}\""
	echo $RETMSG >> $fLOG
#	echo $fTMP
	echo $RETMSG > $fTMP
	echo $RETMSG
	rsync -av $fTMP ${REPO}::TMP/zabbixup_${sUPDATE_TIME}_fail/
	rm -f $fTMP
	exit 1
    fi

    dLASTIP=`echo $IPADDR | awk -F'.' '{print $4}'`
    let "dLASTIP= $dLASTIP % ${dMOD}"

    if [ $dLASTIP -gt 0 ];then
        RETMSG="$sDATE $sHOSTNAME $IPADDR [OK] \"update pass!\" \"${sUPDATE_TIME} mod-${dMOD} remainder-${dLASTIP}\""
	echo $RETMSG
	echo $RETMSG >> $fLOG
	exit 0
    fi

    if [ ! -f ${fLASTUPDATE} ];then
	echo $sDATE > ${fLASTUPDATE}
    fi
    sLASTUP=`cat ${fLASTUPDATE}`
else
    sUPDATE_TIME=`/usr/bin/curl --connect-timeout 2 ${REPO}/zabbixup/updatetime 2> /dev/null`
    sLASTUP=0
fi

echo "========================================================================================================="

# 숫자가 아니면..
[ ! -z "${sLASTUP//[0-9]/}" ] && sLASTUP=201
[ -z ${sLASTUP} ] && sLASTUP=201

[ ! -z "${sUPDATE_TIME//[0-9]/}" ] && sUPDATE_TIME=0
[ -z ${sUPDATE_TIME} ] && sUPDATE_TIME=0

if [ $bFORCE -eq 1 ] || [ ${sLASTUP:0:3} != 201 ] || [ ${sUPDATE_TIME} -gt ${sLASTUP} ];then
    mi=$RANDOM
    let "mi %= 60"
    M=`echo $mi`
    ho=$RANDOM;
    let "ho %= 24"
    H=`echo $ho`

    echo "sleep $M ${sUPDATE_TIME} -gt ${sLASTUP}"
    [ $bFORCE -eq 0 ] && sleep $M

    [ -f /etc/init.d/zabbix_agentd ] && /etc/init.d/zabbix_agentd stop
    killall -9 zabbix_agentd

    if [ $sOSTYPE = 'RH' ];then
	rpm -q zabbix-agentd >& /dev/null && rpm -e zabbix-agentd --nodeps
	rpm -q zabbix-agentd >& /dev/null && rpm -e zabbix-agentd --noscripts
	rsync -avL $REPO::D/STD/zabbix/scripts/zabbix_agentup.sh ${APPROOT}/zabbix/scripts/
	if [ "0${sIDC}" = "0I" ] || [ "0${sIDC}" = "0C" ] || [ "0${sIDC}" = "0S" ];then
	    if [ "0$OSVER" = "0EL4" ];then
		rsync -avL $REPO::D/STD/traceroute/traceroute-2.0.1-6.el4.skp.${sARCH}.rpm /root/job/
		rpm -Uvh /root/job/traceroute-2.0.1-6.el4.skp.${sARCH}.rpm

		rsync -avL $REPO::D/STD/OS/kernel-utils-2.4-18.el4.${sARCH}.rpm /root/job/
		rpm -Uvh /root/job/kernel-utils-2.4-18.el4.${sARCH}.rpm

		rsync -avL $REPO::D/STD/zabbix/rpms/zabbix-agentd-2.2.el4.skp.${sARCH}.rpm /root/job/
		rpm -ivh /root/job/zabbix-agentd-2.2.el4.skp.${sARCH}.rpm
		[ $? -ne 0 ] && exit 10
	    else
		yum clean all
		yum -y install zabbix-agentd
		[ $? -ne 0 ] && exit 10
	    fi
	else
	    # ETC IDC
#	    if [ "0${sARCH}" = "0i686" ] && [ "0$OSVER" = "0EL5" ];then
#		sARCH=i386
#	    fi
	    if [ "0$OSVER" = "0EL6" ];then
		rsync -avL $REPO::D/STD/zabbix/rpms/zabbix-agentd-2.2.el6.skp.${sARCH}.rpm /root/job/
		rpm -ivh /root/job/zabbix-agentd-2.2.el6.skp.${sARCH}.rpm
		[ $? -ne 0 ] && exit 10
	    elif [ "0$OSVER" = "0EL5" ] || [ "0$OSVER" = "0XEN" ];then
#		traceroute -T -p 80 $REPO
		rsync -avL $REPO::D/STD/traceroute/traceroute-2.0.1-6.el5.${sARCH}.rpm /root/job/
		rpm -Uvh /root/job/traceroute-2.0.1-6.el5.${sARCH}.rpm

		rsync -avL $REPO::D/STD/zabbix/rpms/zabbix-agentd-2.2.el5.skp.${sARCH}.rpm /root/job/
		rpm -ivh /root/job/zabbix-agentd-2.2.el5.skp.${sARCH}.rpm
		[ $? -ne 0 ] && exit 10
	    elif [ "0$OSVER" = "0EL4" ];then
		rsync -avL $REPO::D/STD/traceroute/traceroute-2.0.1-6.el4.skp.${sARCH}.rpm /root/job/
		rpm -Uvh /root/job/traceroute-2.0.1-6.el4.skp.${sARCH}.rpm

		rsync -avL $REPO::D/STD/OS/kernel-utils-2.4-18.el4.${sARCH}.rpm /root/job/
		rpm -Uvh /root/job/kernel-utils-2.4-18.el4.${sARCH}.rpm

		rsync -avL $REPO::D/STD/zabbix/rpms/zabbix-agentd-2.2.el4.skp.${sARCH}.rpm /root/job/
		rpm -ivh /root/job/zabbix-agentd-2.2.el4.skp.${sARCH}.rpm
		[ $? -ne 0 ] && exit 10
	    fi
	fi
    elif [ $sOSTYPE = 'UT' ];then
	dpkg --purge --force-all zabbix-agentd
	rsync -avL $REPO::D/STD/zabbix/scripts/zabbix_agentup.sh ${APPROOT}/zabbix/scripts/
	if [ "0${sIDC}" = "0I" ] || [ "0${sIDC}" = "0C" ] || [ "0${sIDC}" = "0S" ];then
	    #apt-get update
	    apt-get -y --force-yes install zabbix-agentd
	else
	    # ETC IDC
	    if [ "0${sARCH}" != "0x86_64" ] || [ "0${sIDC}" = "0M" ];then
		echo "i686 not support"
		exit 99
	    fi
	    rsync -av $REPO::D/STD/zabbix/ubuntu/zabbix-agentd_2.0.4-3.skp_amd64.deb /root/job/
	    dpkg -i /root/job/zabbix-agentd_2.0.4-3.skp_amd64.deb
	fi
	    dpkg -l |grep zabbix-agentd
	    [ $? -ne 0 ] && exit 10
	    rsync -av ${REPO}::D/STD/zabbix/ubuntu/zabbix-agentd_ubuntu-init /etc/init.d/zabbix_agentd
	    rsync -av ${REPO}::D/STD/zabbix/scripts/garbage-disposal.sh ${APPROOT}/zabbix/scripts/
    else
	echo "Not support ostype - $sOSTYPE"
	exit 98
    fi

    if [ ! -x /etc/init.d/zabbix_agentd ];then
	if [ "0${sIDC}" = "0I" ] || [ "0${sIDC}" = "0C" ] || [ "0${sIDC}" = "0S" ];then
	    cp -a /etc/yum.repos.d/ /etc/yum.repos.d_${sDATE}/
	    find /etc/yum.repos.d/ -type f \! \( -name skp.repo \) -exec rm -f {} \;
	fi
	RETMSG="$sDATE $sHOSTNAME $IPADDR [ERR] \"Zabbix rpm install FAIL!\" \"${sUPDATE_TIME}\""
	echo $RETMSG >> $fLOG
	echo $RETMSG > $fTMP
	echo $RETMSG 
	rsync -av $fTMP ${REPO}::TMP/zabbixup_${sUPDATE_TIME}_fail/
	rm -f $fTMP
	exit 1
    fi

    /etc/init.d/zabbix_agentd stop

    echo $sUPDATE_TIME > ${fLASTUPDATE}
    RETMSG="$sDATE $sHOSTNAME $IPADDR [OK] \"update ok!\" \"${sUPDATE_TIME}-${sLASTUP}\""

    echo $RETMSG > $fTMP
    rsync -av $fTMP ${REPO}::TMP/zabbixup_${sUPDATE_TIME}_ok/
    rm -f $fTMP

    if [ "0$NETaddr" = "010.10.93" ];then
	#if openstack
	echo "bond0:1000:load balancing:2" > /app/zabbix/etc/bond.conf
	echo "bond1:1000:load balancing:1" >> /app/zabbix/etc/bond.conf
	echo "bond2:1000:fault-tolerance:2" >> /app/zabbix/etc/bond.conf
    fi

    ${APPROOT}/zabbix/scripts/garbage-disposal.sh -f all
#    ${APPROOT}/zabbix/scripts/garbage-disposal.sh -f all
    /etc/init.d/zabbix_agentd stop
    /etc/init.d/zabbix_agentd start
else 
    RETMSG="$sDATE $sHOSTNAME $IPADDR [OK] \"update pass!\" \"${sUPDATE_TIME}-${sLASTUP}\""
fi

echo "========================================================================================================="

echo $RETMSG
echo $RETMSG >> $fLOG
exit 0
