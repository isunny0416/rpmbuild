#!/bin/bash

# password expired account search.

TODAY=$((`date +%s` / 86400))


#ACCOUNTS=`egrep -v "/sbin/nologin|/bin/false|^root" /etc/passwd | awk -F ":" '{print $1}'`
ACCOUNTS=`egrep -v "/sbin/nologin|/bin/false" /etc/passwd | awk -F ":" '{print $1}'`

#echo $ACCOUNTS

for account in $ACCOUNTS
do
    [ `echo $account | grep -c '_con$'` -ge 1 ] && continue

#    echo $account 

    SHOK=`/bin/grep "^${account}" /etc/shadow`
    [ $? -ne 0 ] && continue;
    PWSTR=`echo $SHOK | awk -F: '{print $2}'`
    if [ "A$PWSTR" = 'A!!' ] || [ "A$PWSTR" = 'A*' ];then
	continue;
    fi

    EXPIREDAY=`egrep ^${account} /etc/shadow | awk -F ":" '{EXPDATE=$3+$5} END {print EXPDATE}'`
    if [ $EXPIREDAY -lt $TODAY ];then
	echo -n "${account}:"
    fi
done

echo "";
exit 0
