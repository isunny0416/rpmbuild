#!/bin/bash

cDATE=`date "+%Y%m%d%H%M"`

echo "`date` [START] restart zabbix agent" 

#exec &>> /app/zabbix/log/zagent_restart.log
#exec &> >(tee -a /app/zabbix/log/zagent_restart.log)

(
echo "`date` [START] restart zabbix agent" 
sleep 40

if [ -x /etc/init.d/zabbix_agentd ];then
    /etc/init.d/zabbix_agentd restart
elif [ -x /etc/init.d/zabbix-agent ];then
    /etc/init.d/zabbix-agent restart
fi

echo "`date` [END] restart zabbix agent" 
) >> /app/zabbix/log/zagent_restart.log 2>&1 &

exit 0
