#!/bin/bash
## last modify hc.song@sk.com  2014/02/05

unset LANG

cDATE=`date "+%Y%m%d%H%M"`
ZABBIX_PREFIX="/app/zabbix"
TMPFILE="/tmp/zabbix_active"

/bin/find ${TMPFILE}.* -type f -amin +100 -exec rm -f {} \; >& /dev/null


${ZABBIX_PREFIX}/bin/zabbix_sender -c ${ZABBIX_PREFIX}/etc/zabbix_agentd.conf -k active_check -o 1  -vv >& ${TMPFILE}.${cDATE}

VER=`${ZABBIX_PREFIX}/bin/zabbix_sender -V |grep "Zabbix Sender v" | awk '{print $3}'`

if [ "0${VER:0:4}" = "0v2.0" ];then
    if [ -f ${TMPFILE}.${cDATE} ] && [ `grep "info\"" ${TMPFILE}.${cDATE} | awk '{print $4}'` -ge 1 ]; then
#	ls ${TMPFILE}.${cDATE}
#	cat ${TMPFILE}.${cDATE}
	echo 1; exit 1
    fi
else
    if [ -f ${TMPFILE}.${cDATE} ] && [ `grep "info\"" ${TMPFILE}.${cDATE} | awk '{print $4}' | sed 's/;//g'` -ge 1 ]; then
	echo 1; exit 1
    fi
fi

exit 0
