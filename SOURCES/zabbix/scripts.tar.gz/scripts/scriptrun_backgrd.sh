#!/bin/bash

source /etc/profile >& /dev/null
if [ -z $REPO ];then
    REPO="10.10.100.20"
fi

MAILFROM="scripts_run@sk.com"
#MAILTO="infra.ilsan@skplanet.com"
MAILTO="hc.song@sk.com"

PROG=$1

DATE=$2
ScriptNAME=`basename $PROG`
LOGFILE=/tmp/${ScriptNAME}.log

sHOSTNAME=`hostname -s`
#sIP=`/sbin/ifconfig | grep "inet addr" |grep -v 127.0.0.1 | sed -e s/Bcast//g -e s/Mask//g |awk -F: '{print $2}' | head -n 1`
sIP=`/sbin/ip addr | grep -w inet | egrep -v '127.0.0.1|/32' | awk '{ print $2 }' | egrep -o '[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}' | egrep -v '^211.|^1.234|^175.' | head -n 1`

echo "======================================================================================="
echo "zabbix back-ground script run"
echo "Script : ${PROG}"
echo "HOST : ${sHOSTNAME}_${sIP}"
echo "DATE : ${DATE}"
echo "======================================================================================="
echo
echo "= Result =============================================================================="

$PROG
echo "======================================================================================="
echo "END time : `date "+%Y%m%d%H%M%S"`"
echo "======================================================================================="

mv -f ${LOGFILE} ${LOGFILE}_${sHOSTNAME}_${sIP}

rsync -av ${LOGFILE}_${sHOSTNAME}_${sIP} ${REPO}::TMP/scriptrun_${ScriptNAME}_${DATE}/ >& /dev/null
echo
echo "= Result Push ========================================================================="
echo "rsync -av ${LOGFILE}_${sHOSTNAME}_${sIP} ${REPO}::TMP/scriptrun_${ScriptNAME}_${DATE}/"
echo "======================================================================================="

RET="`cat ${LOGFILE}_${sHOSTNAME}_${sIP}`"

#/usr/bin/send_mail.py $MAILFROM $MAILTO "[Script-Run] ${sHOSTNAME}(${sIP}) ${ScriptNAME}_${DATE}" "`cat ${LOGFILE}_${sHOSTNAME}_${sIP}`"
[ -x /usr/bin/send_mail.py ] && /usr/bin/send_mail.py $MAILFROM $MAILTO "[Script-Run] ${sHOSTNAME}(${sIP}) ${ScriptNAME}_${DATE}" "${RET:0:131070}"

exit 0
