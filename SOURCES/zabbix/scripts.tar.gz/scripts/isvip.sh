#!/bin/bash

source /etc/profile >& /dev/null
unset LANG

sIP="$1"

if [ `/sbin/ip addr | grep inet | grep -w $sIP | grep -c "secondary"` -ge 1 ];then
        echo "1"
	exit 1
elif [ `/sbin/ip addr | grep inet | grep -w $sIP | grep -c "/32"` -ge 1 ];then
    echo "2"
    exit 2
fi

echo "0"
exit 0

